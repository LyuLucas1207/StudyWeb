const addToCart = document.querySelector(".addToCart");
addToCart.addEventListener("click", () => {
	addToCart.classList.toggle("added");
});
